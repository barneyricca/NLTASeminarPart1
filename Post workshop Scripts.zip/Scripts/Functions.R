nl_cross_pred <- function(ts,               # time series signal
                          nseg = 5,         # number of segments
                          m.max = 6) {      # To allow for limiting the

  mean(ts, na.rm = TRUE) ->                 # Simple mean imputation of missing
    ts[is.na(ts)]                           #  data. Do this better! (Kalman?)

  # Step 1: Segment time series x(t)
  seg.length <- floor(length(ts)/nseg)      # length of each segment

  ts[1:(seg.length*nseg)] ->                # Possibly ignore a few data points
    ts                                      #  at the end (remainders)
  c(seg.length, nseg) ->                    # Store ts as a matrix with nseg
    dim(ts)                                 #  columns
  # matrix(ts[1:(seg.length*nseg)],
  #        ncol = nseg,
  #        nrow = seg.length,
  #        byrow = FALSE) ->
  #   seg.matrix

  #Step 2: Nonlinear cross prediction
  matrix(0,                                 # Matrix of Nash-Sutcliffe
         nseg,                              #  efficiences across the segments.
         nseg) ->
    nse.matrix
  for(i2 in 1:nseg) {           # loop over learning sets
    # Inner loop (i3) iterates over test sets to be predicted by each learning
    #  set. The matrix 'hold.nse' is a column vector storing Nash-Sutcliffe
    #  efficiencies for the predicted test sets (rows) by a given learning set.
    #ts -> ts.keep

    #print(paste0("i2: ", i2, sep = ""))
    hold.nse <- matrix(0, nseg, 1)
    for(i3 in 1:nseg) { #loop over test sets
      #print(paste0("i3: ", i3, sep = ""))

      #ts.keep -> ts

      # seg.matrix[,i2] ->                    # Learning set for forecast
      #   learn
      # seg.matrix[,i3] ->                    # Test set for forecast
      #   test
      ts[,i2] -> learn                        # Learning set for forecast
      ts[,i3] -> test                         # Test set for forecast

      #Step 2a: embedding
      const_delay_embed(learn) ->
        results.embed
      results.embed$delay -> d
      results.embed$dim -> m
      results.embed$embedded ->
        learn.em.0

      # Embed the test data using the same parameters as the learn data. This
      #  might be done faster by hand.
      tseriesChaos::embedd(test,m,d) ->     # initial embedded test set
        test.em
      rbind(learn.em.0,test.em) -> # Stack for use in prediction loop
        Mx

      #
      #
      # OK TO HERE
      #
      #
      #Step 2b: Nonlinear prediction
      results.np<-nse(Mx)

      ns<-results.np[[1]]
      hold.nse[i3,]<-ns
    } #end i3 loop through test sets
    nse.matrix[,i2]<-hold.nse
    nse.matrix[is.na(nse.matrix)] <- 1 #set any na's along diagonal = 1
  } #end i2 loop through learning sets
  #Plot of nse.matrix. Each line shows the Nash-Sutcliffe efficiencies for a given
  #learning set (column of nse.matrix) in 1-step prediction of each test set
  #(rows of nse.matrix) along horizontal axis.
  plot(nse.matrix[,1],type='l',
       xlab="test sets predicted",ylab="nse",ylim=c(0,1),
       font=2,font.lab=2,cex.axis=2,cex.lab=2)
  for(i4 in 2:ncol(nse.matrix)) {
    graphics::lines(nse.matrix[,i4],
                    col = i4)
  } #end loop

  return(nse.matrix)
}


nse <- function(ts,
                frac.learn = 0.5) { # fraction in learning set

  # Alternative: hydroGOF::NSE()? That works without emedding, though.

  if(mode(as.matrix(ts)) != "numeric") {
    cat("ts must be numeric!\n")
    return(NULL)
  }

  # Hmm...if ts is not a vector, then it is already embedded, and we should
  #  skip step 1?
  if(is.null(dim(ts))) {
    #Step 1: Time-delay embedding
    #Embed time series (ts)  l
    results.embed_udf<-const_delay_embed(ts)
    m<-results.embed_udf$dim #embedding dimension
    Mx<-results.embed_udf$embedded #embedded data matrix
  } else {
    if(length(dim(ts)) == 2) {
      ts -> Mx
      dim(Mx)[2] -> m
    } else {
      stop("Dimensionality issue with ts in nse()\n")
    }
  }

  # Ties are a problem, so add small random noise to the data
  Mx + stats::rnorm(n = nrow(Mx) * ncol(Mx),
                    mean = 0,
                    sd = min(stats::sd(Mx, na.rm = TRUE) / 1e3,
                             1e-3)) ->
    Mx

  #Step 2a: Partition Mx into learning and test sets
  # Original:
  # learn.rows<-round(frac.learn * nrow(Mx))
  # Revised:
  floor(frac.learn * nrow(Mx)) ->
    learn.rows

  # After the next, the top half of Mx should be in learn.em.0, while the
  #  bottom half of Mx should be in test.em
  learn.em.0<-Mx[1:learn.rows,] #initial learning set
  test.em<-Mx[(learn.rows+1):nrow(Mx),] #initial test set

  #Step 2b: Prediction
  hold.test<-matrix(0,learn.rows,1)
  hold.pred<-matrix(0,learn.rows,1)

  # Using the Mayport data (with the -99999, not with NA), we see this:
  # For i == 18, there are two dist.ref values that equal zero. Why?
  #  They are at 6 and 451. 451 is the reference point. But why 6?
  # The problem occurs with i = these values:
  # [1]  18 104 109 161 188 199
  #
  #
  # I think just using the smallest non-zero value for u.denom would be
  #  appropriate. At least, it would get past this for now.
  #
  #
  for(i in 1:learn.rows) {
    #print("i");print(i)
    Mx[1:((learn.rows + i) - 1),] ->
      learn.em
    #print("learn.em");print(learn.em)

    #Step 2b(1): Calculate nearest neighbours to last row in learning set
    #  (i.e., learn.em.0). Should this be learn.em, or should the ref point
    #  be learn.em.0?
    #Distance between points on the attractor
    ref.point <- nrow(learn.em) #index of reference point

    # Alternatives:
    # stat::dist(learn.em, diag = TRUE, upper = TRUE) gives the same things.
    # FNN:get.knn() gives almost the same information, but still needs to
    #  be normalized. (It is also sqrt(2) larger for the Hare data.)
    dist<-fields::rdist(learn.em) #distance matrix;

    dist.ref<-dist[,ref.point] #distances from reference point to other points
    sc<-max(dist.ref) #find maximum distance from reference point
    dist.ref.sc<-dist.ref/sc #scale distances from reference point to max distance

    o<-order(dist.ref.sc)  #Remove distance of reference point to itself
    remove<-which(o==nrow(learn.em))

    o1<-o[-remove]
    #Indices of m+1 smallest distances from reference point
    # (m=embedding dimension)
    o2<-o1[1:(m+1)]
    o2<-stats::na.omit(o2)
    dist.ordered<-dist.ref.sc[o2] #ordered distances
    #dist.ordered
    # Alternative
    # library(FNN)
    # get.knn(data = cbind(learn.em, learn.em),
    #         k = 3) ->
    #   dum1
    # dum1$nn.index[27,]
    # dum1$nn.dist[27,]
    # # All are sqrt(2) longer distances than KBR method.
    # # Normalizing still must be done.

    #Increment neighbouring indices by 1 period for use in prediction algorithm
    # These are the next points for the nearest neighbors of the current point
    #  on the trajectory. These next points are used to predict the next point
    #  on this trajectory, which will later be compared to the actual next
    #  point on this trajectory.
    o.pred<-o2+1
    pred.ngh<-learn.em[o.pred,] #Nearest neighbours
    #Step 2b(2): Compute prediction as average of neighbouring points weighted by
    #distances from reference point
    # Compute weights (Sughihara et al., 2012)

    # Original:
    u.denom<-dist.ordered[1] #distance from reference point to nearest neighbour

    # This could be vectorized:
    # hold<-matrix(0,(m+1),1)
    # for(k in 1:(m+1)) { #summands in w.denom
    #   #      u.vector<-ifelse(
    #   #        u.denom == 0 & dist.ordered[k] != 0,
    #   #        0,
    #   u.vector <- exp(-dist.ordered[k]/u.denom)
    #   hold[k,1]<-u.vector
    # } #end loop k

    #  u.vector<-hold[1:(m+1)]
    exp(-dist.ordered/u.denom) ->           # This is vectorized
      u.vector # -> hold[,1]

    # w.denom<-sum(u.vector)
    w.vector<-u.vector / sum(u.vector)
    #w.vector
    #Prediction of next point on attractor (row in test.em)
    # HBR does not cast the data frame to a matrix; that must be done. (That
    #  might have been a change with R 4.0.0, IIRC.)
    pred.point<-w.vector %*% as.matrix(pred.ngh)
    #pred.point
    #Prediction of time series observation is first (unlagged) element of
    #pred.point
    pred.ts<-pred.point[1]
    #print("pred.ts");print(pred.ts)
    #Step 2b(3): Test point on attractor (row in test.em)
    test.point<-test.em[i,]

    #print("test.point");print(test.point)
    #Time series observation to be validated is first (unlagged) element of
    #  test.point
    test.ts<-test.point[1]
    hold.test[i,]<-test.ts #1st element is original data point
    hold.pred[i,]<-pred.ts
    #hold.test[i,]
    #hold.pred[i,]
  } #end i loop through Mx

  # Hmm...the first element consistently seems to be orders of magnitude
  #  different than the others. I don't know why, but removing that brings
  #  things more into line. Let's see if that works for now.
  1 - (sum((hold.test[-1] - hold.pred[-1])^2) /     # Estimate the NSE
         sum((hold.test[-1] - mean(hold.test[-1]))^2)) ->
    nse
  #print("nse");print(hold.mnse)
  #results<-cbind(learn.0,hold.test,hold.pred)
  #print("learn,test,pred");print(results)
  results<-list("nse" = nse,
                "test" = hold.test,
                "predicted" = hold.pred)
  return(results)
} #end function

mi_ksg <- function(ts,                      # A numeric vector of a timeseries
                   k = 3,                   # Number of nearest neighbors
                   lag.max = 100) {         # Maximum lag
  # Some day, after implementing KDE approaches, etc., deprecate this.
  #  The body of this will have to be something like:
  #  {return(ami(ts, method = "KSG", k = k))} to call the full ami calculation.

  # Check ts (numeric vector)

  # Check lag.max (positive integer)

  if((mode(k) == "numeric" |                # Make certain k is a positive
      mode(k) == "integer") &               #  integer
     k %% 1 == 0 &
     k >= 1) {

    min(length(ts) - k - 1,
        lag.max) ->
      lag.max

    if(lag.max <= 0) {
      cat("Invalid lag.max in mi_ksg!\n")
      return(NULL)
    }

    vector(mode = "numeric",
           length = lag.max + 1) ->
      mi
    for(index in 0:lag.max) {
      # print(index)
      # NaN produces for index 0:11, and none after that.

      # Too many ties creates a big problem. So, add a little noise to
      #  avoid that.
      FNN::mutinfo(ts[1:(length(ts) - index)] +
                     stats::rnorm(length(ts) - index,
                                  0,
                                  min(1e-5,
                                      stats::sd(ts, na.rm = TRUE) / 1e3)),
                   ts[(index+1):(length(ts))],
                   k = k) ->
        mi[index + 1]
    }
    return(mi)
  } else {
    cat("k must be a positive integer!\n")
    return(NULL)
  }
}

const_delay_embed <- function(x,
                              m.max = 6,  # Maximum embedding dimension
                              max.delay = 20,
                              lag.max = 100,
                              tol = 0.15) {

  # Issue Number 1:
  # tseriesChaos::mutual() and nonlinearTseries::mutualInformation() give
  #  different AMI estimates for the Hare embedding. This is problematic
  #  because they also give different estimates of the delay. The former
  #  yields a delay of 4, while the latter yields a delay of 3.
  #
  mean(x,
       na.rm = TRUE) ->
    x[is.na(x) == TRUE]
  # NOTA BENE: HBR neglected to deal with the missing data (marked -99999) in
  #  the chapter 6 example, so their results are different than what we get
  #  here!

  mi_ksg(x) -> mi

  # First minimum, from jamie.f.olson. See details at:
  # https://stackoverflow.com/questions/6836409/finding-local-maxima-and-minima
  which(diff(diff(mi)>0)>0)[1] ->           # This is the one we want.
    d

  acf.out <- stats::acf(x,
                        lag.max,
                        plot = FALSE)$acf

  # First minimum, from jamie.f.olson. See details at:
  # https://stackoverflow.com/questions/6836409/finding-local-maxima-and-minima
  which(diff(diff(acf.out)>0)>0)[1] ->      # This is the one we want.
    tw

  min(m.max,
      floor(length(x)/d) - 1) ->
    m.dim
  if(m.dim < 0) {
    cat("Dimension in embed_local must be positive!\n")
    return(NULL)
  }

  min(length(x) - m.dim * d - 1,
      tw) ->
    tw
  if(tw < 0) {
    cat("Theiler window in embed_local must be positive!\n")
    return(NULL)
  }

  tseriesChaos::false.nearest(series = x,   # Possible error for short series?
                              m = m.dim,
                              d = d,
                              t = tw) ->    #
    fn.out
  fn.out[is.na(fn.out)] <- 0                # set NA in fn.out to zero

  fn.out[2*(1:m.max)-1] ->                  # Output vector of fnn percentages
    fnp                                     #  from fn.out.
  ifelse(                                   # Minimum delay that is < tol
    suppressWarnings(
      is.infinite(min(which(fnp < tol)))),
    m.max,
    min(which(fnp < tol))) ->
    m                                       # Embedding dimension

  ifelse(m <= 1,                            # Must embed in more than 1 dim
         2,
         m) ->
    m
  tseriesChaos::embedd(x,m,d) ->            # Embed time series (Mx)
    Mx

  return(list("delay" = d,
              "dim" = m ,
              "tw" = tw,
              "embedded" = Mx))
}

